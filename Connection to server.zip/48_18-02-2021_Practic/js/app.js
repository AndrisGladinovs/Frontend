Api.registration("dayday91@day.com", "Aa123456_")
    .then((response) => {
        console.log(response);
    })
    .catch((error) => {
        console.log(error);
    });